//#define _CRT_SECURE_NO_WARNINGS
//
//#include <stdio.h>
//
//int BOOM(int n)
//{
//    printf("%d", n);
//    n++;
//    BOOM(n);
//}
//
//int main() {
//    unsigned int i;
//    scanf("%d", &i);
//    BOOM(i);
//    return 0;
//}